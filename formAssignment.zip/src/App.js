import React from 'react'
import "./App.css";
import LoginForm from './components/LoginForm';
import LoginFormBootstrap from './components/LoginForm2';

  
const App = () => {
  return (
    <div>
    {/* <LoginForm/> */}
    <LoginFormBootstrap/>
    </div>
  )
}

export default App
